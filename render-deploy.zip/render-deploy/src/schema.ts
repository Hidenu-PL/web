import { pgTable, text, serial, integer, timestamp, pgEnum } from "drizzle-orm/pg-core";

export const archiveStatusEnum = pgEnum("archive_status", ["pending", "processing", "completed", "failed"]);

export const archivesTable = pgTable("archives", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  title: text("title"),
  status: archiveStatusEnum("status").notNull().default("pending"),
  errorMessage: text("error_message"),
  fileSize: integer("file_size"),
  resourceCount: integer("resource_count"),
  archiveData: text("archive_data"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export type Archive = typeof archivesTable.$inferSelect;
