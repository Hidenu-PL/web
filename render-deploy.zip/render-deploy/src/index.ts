import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import { eq, desc, sum, count } from "drizzle-orm";
import * as cheerio from "cheerio";
import JSZip from "jszip";
import fetch from "node-fetch";
import { URL } from "url";
import * as schema from "./schema.js";
import pino from "pino";
import pinoHttp from "pino-http";

const { archivesTable } = schema;
const { Pool } = pg;

const __dirname = path.dirname(fileURLToPath(import.meta.url));

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool, { schema });

const logger = pino({ level: "info" });
const app = express();

app.use(pinoHttp({ logger }));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── Archiving logic ──────────────────────────────────────────────────────────

const MAX_RESOURCES = 300;
const PAGE_FETCH_TIMEOUT = 20000;
const RESOURCE_FETCH_TIMEOUT = 10000;

function sanitizeFilename(name: string): string {
  return name.replace(/[^a-z0-9_.-]/gi, "_").substring(0, 120);
}

function hashCode(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return hash;
}

function getExtension(url: string, contentType: string): string {
  try {
    const ext = new URL(url).pathname.split(".").pop()?.toLowerCase() ?? "";
    if (ext && ext.length >= 1 && ext.length <= 5 && /^[a-z0-9]+$/.test(ext)) return ext;
  } catch {}
  if (contentType.includes("text/css")) return "css";
  if (contentType.includes("javascript")) return "js";
  if (contentType.includes("text/html")) return "html";
  if (contentType.includes("image/png")) return "png";
  if (contentType.includes("image/jpeg")) return "jpg";
  if (contentType.includes("image/gif")) return "gif";
  if (contentType.includes("image/webp")) return "webp";
  if (contentType.includes("image/svg")) return "svg";
  if (contentType.includes("image/avif")) return "avif";
  if (contentType.includes("image/ico") || contentType.includes("image/x-icon")) return "ico";
  if (contentType.includes("font/woff2")) return "woff2";
  if (contentType.includes("font/woff")) return "woff";
  if (contentType.includes("font/ttf") || contentType.includes("font/truetype")) return "ttf";
  if (contentType.includes("font/otf")) return "otf";
  return "bin";
}

async function fetchResource(url: string, timeoutMs: number): Promise<{ data: Buffer; contentType: string } | null> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "*/*",
      },
      redirect: "follow",
    });
    clearTimeout(t);
    if (!res.ok) return null;
    const contentType = res.headers.get("content-type") ?? "application/octet-stream";
    return { data: Buffer.from(await res.arrayBuffer()), contentType };
  } catch {
    return null;
  }
}

function resolveUrl(src: string, base: string): string | null {
  const t = src?.trim();
  if (!t || t.startsWith("data:") || t.startsWith("javascript:") || t.startsWith("#") || t.startsWith("blob:")) return null;
  try { return new URL(t, base).href; } catch { return null; }
}

function extractCssUrls(css: string, base: string): string[] {
  const urls: string[] = [];
  for (const m of css.matchAll(/url\(\s*['"]?([^'")\s]+)['"]?\s*\)/g)) {
    const r = resolveUrl(m[1], base);
    if (r) urls.push(r);
  }
  for (const m of css.matchAll(/@import\s+['"]([^'"]+)['"]/g)) {
    const r = resolveUrl(m[1], base);
    if (r) urls.push(r);
  }
  return urls;
}

async function archivePage(archiveId: number, pageUrl: string) {
  await db.update(archivesTable).set({ status: "processing" }).where(eq(archivesTable.id, archiveId));

  try {
    const page = await fetchResource(pageUrl, PAGE_FETCH_TIMEOUT);
    if (!page) throw new Error("Failed to fetch the page");

    const html = page.data.toString("utf-8");
    const $ = cheerio.load(html);
    const pageTitle = $("title").text()?.trim() || null;
    const zip = new JSZip();
    const resourceMap = new Map<string, string>();
    const seen = new Set<string>();
    const queue: string[] = [];

    function add(src: string | undefined | null) {
      if (!src) return;
      const r = resolveUrl(src, pageUrl);
      if (r && !seen.has(r)) { seen.add(r); queue.push(r); }
    }

    function addSrcset(srcset: string | undefined) {
      if (!srcset) return;
      srcset.split(",").forEach(s => add(s.trim().split(/\s+/)[0]));
    }

    $("link[rel='stylesheet'], link[type='text/css']").each((_, el) => add($(el).attr("href")));
    $("link[rel='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']").each((_, el) => add($(el).attr("href")));
    $("link[rel='preload']").each((_, el) => add($(el).attr("href")));
    $("script[src]").each((_, el) => add($(el).attr("src")));
    $("img").each((_, el) => {
      add($(el).attr("src"));
      add($(el).attr("data-src"));
      addSrcset($(el).attr("srcset"));
      addSrcset($(el).attr("data-srcset"));
    });
    $("source").each((_, el) => { add($(el).attr("src")); addSrcset($(el).attr("srcset")); });
    $("video").each((_, el) => { add($(el).attr("src")); add($(el).attr("poster")); });
    $("audio").each((_, el) => add($(el).attr("src")));
    $("picture source").each((_, el) => addSrcset($(el).attr("srcset")));
    $("input[type='image']").each((_, el) => add($(el).attr("src")));
    $("[background]").each((_, el) => add($(el).attr("background")));
    $("meta[property='og:image'], meta[name='twitter:image']").each((_, el) => add($(el).attr("content")));
    $("[style]").each((_, el) => {
      extractCssUrls($(el).attr("style") ?? "", pageUrl).forEach(u => { if (!seen.has(u)) { seen.add(u); queue.push(u); }});
    });

    const toFetch = queue.slice(0, MAX_RESOURCES);
    let fetchedCount = 0;
    const cssEntries: { text: string; base: string }[] = [];

    await Promise.allSettled(toFetch.map(async (url) => {
      const r = await fetchResource(url, RESOURCE_FETCH_TIMEOUT);
      if (!r) return;
      fetchedCount++;
      const ext = getExtension(url, r.contentType);
      const fileName = `resources/${sanitizeFilename(new URL(url).hostname + new URL(url).pathname + "_" + Math.abs(hashCode(url)))}.${ext}`;
      zip.file(fileName, r.data);
      resourceMap.set(url, fileName);
      if (r.contentType.includes("text/css")) cssEntries.push({ text: r.data.toString("utf-8"), base: url });
    }));

    const extraSeen = new Set(seen);
    const extraUrls: string[] = [];
    for (const { text: cssText, base } of cssEntries) {
      for (const u of extractCssUrls(cssText, base)) {
        if (!extraSeen.has(u)) { extraSeen.add(u); extraUrls.push(u); }
      }
    }

    const remaining = Math.max(0, MAX_RESOURCES - toFetch.length);
    await Promise.allSettled(extraUrls.slice(0, remaining).map(async (url) => {
      const r = await fetchResource(url, RESOURCE_FETCH_TIMEOUT);
      if (!r) return;
      fetchedCount++;
      const ext = getExtension(url, r.contentType);
      const fileName = `resources/${sanitizeFilename(new URL(url).hostname + new URL(url).pathname + "_" + Math.abs(hashCode(url)))}.${ext}`;
      zip.file(fileName, r.data);
      resourceMap.set(url, fileName);
    }));

    let modifiedHtml = html;
    for (const [origUrl, localPath] of resourceMap) {
      modifiedHtml = modifiedHtml.split(origUrl).join(localPath);
      try {
        const urlObj = new URL(origUrl);
        modifiedHtml = modifiedHtml.split(urlObj.pathname + urlObj.search).join(localPath);
      } catch {}
    }

    zip.file("index.html", modifiedHtml);
    zip.file("archive-info.txt", `Archived URL: ${pageUrl}\nDate: ${new Date().toISOString()}\nResources: ${fetchedCount + 1}\n`);

    const zipBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE", compressionOptions: { level: 6 } });

    await db.update(archivesTable).set({
      status: "completed", title: pageTitle,
      fileSize: zipBuffer.length, resourceCount: fetchedCount + 1,
      archiveData: zipBuffer.toString("base64"), completedAt: new Date(),
    }).where(eq(archivesTable.id, archiveId));

  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    await db.update(archivesTable).set({ status: "failed", errorMessage: message, completedAt: new Date() }).where(eq(archivesTable.id, archiveId));
  }
}

// ─── API Routes ───────────────────────────────────────────────────────────────

app.get("/api/healthz", (_req, res) => res.json({ status: "ok" }));

app.get("/api/archive/stats", async (_req, res) => {
  const rows = await db.select({ status: archivesTable.status, cnt: count(), totalSize: sum(archivesTable.fileSize) })
    .from(archivesTable).groupBy(archivesTable.status);
  let total = 0, completed = 0, pending = 0, failed = 0, totalSizeBytes = 0;
  for (const row of rows) {
    total += Number(row.cnt);
    if (row.status === "completed") { completed += Number(row.cnt); totalSizeBytes += Number(row.totalSize ?? 0); }
    else if (row.status === "pending" || row.status === "processing") pending += Number(row.cnt);
    else if (row.status === "failed") failed += Number(row.cnt);
  }
  res.json({ total, completed, pending, failed, totalSizeBytes });
});

app.get("/api/archive", async (_req, res) => {
  const archives = await db.select({
    id: archivesTable.id, url: archivesTable.url, title: archivesTable.title,
    status: archivesTable.status, errorMessage: archivesTable.errorMessage,
    fileSize: archivesTable.fileSize, resourceCount: archivesTable.resourceCount,
    createdAt: archivesTable.createdAt, completedAt: archivesTable.completedAt,
  }).from(archivesTable).orderBy(desc(archivesTable.createdAt)).limit(50);
  res.json(archives);
});

app.post("/api/archive", async (req, res) => {
  let urlStr: string = (req.body?.url ?? "").trim();
  if (!urlStr) { res.status(400).json({ error: "validation_error", message: "URL is required" }); return; }
  if (!urlStr.startsWith("http://") && !urlStr.startsWith("https://")) urlStr = "https://" + urlStr;
  try { new URL(urlStr); } catch { res.status(400).json({ error: "invalid_url", message: "Invalid URL" }); return; }

  const [archive] = await db.insert(archivesTable).values({ url: urlStr }).returning();
  res.status(201).json({
    id: archive.id, url: archive.url, title: archive.title, status: archive.status,
    errorMessage: archive.errorMessage, fileSize: archive.fileSize,
    resourceCount: archive.resourceCount, createdAt: archive.createdAt, completedAt: archive.completedAt,
  });
  setImmediate(() => archivePage(archive.id, urlStr));
});

app.get("/api/archive/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "invalid_id", message: "Invalid ID" }); return; }
  const [archive] = await db.select({
    id: archivesTable.id, url: archivesTable.url, title: archivesTable.title,
    status: archivesTable.status, errorMessage: archivesTable.errorMessage,
    fileSize: archivesTable.fileSize, resourceCount: archivesTable.resourceCount,
    createdAt: archivesTable.createdAt, completedAt: archivesTable.completedAt,
  }).from(archivesTable).where(eq(archivesTable.id, id));
  if (!archive) { res.status(404).json({ error: "not_found", message: "Archive not found" }); return; }
  res.json(archive);
});

app.delete("/api/archive/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "invalid_id", message: "Invalid ID" }); return; }
  const [deleted] = await db.delete(archivesTable).where(eq(archivesTable.id, id)).returning({ id: archivesTable.id });
  if (!deleted) { res.status(404).json({ error: "not_found", message: "Archive not found" }); return; }
  res.status(204).send();
});

app.get("/api/archive/:id/download", async (req, res) => {
  const id = Number(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "invalid_id", message: "Invalid ID" }); return; }
  const [archive] = await db.select().from(archivesTable).where(eq(archivesTable.id, id));
  if (!archive) { res.status(404).json({ error: "not_found", message: "Archive not found" }); return; }
  if (archive.status !== "completed" || !archive.archiveData) {
    res.status(400).json({ error: "not_ready", message: "Archive not completed" }); return;
  }
  const zipBuffer = Buffer.from(archive.archiveData, "base64");
  const filename = sanitizeFilename(new URL(archive.url).hostname) + "_archive.zip";
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.setHeader("Content-Length", zipBuffer.length);
  res.send(zipBuffer);
});

// ─── Serve React frontend static files ───────────────────────────────────────
// These are built by running `npm run build:frontend` in the web-archiver folder
// and copied here as the `public/` directory before deployment.
const publicDir = path.join(__dirname, "../public");
app.use(express.static(publicDir));

// SPA fallback — serve index.html for all non-API routes
app.get("*", (_req, res) => {
  res.sendFile(path.join(publicDir, "index.html"));
});

// ─── Start server ─────────────────────────────────────────────────────────────
const port = Number(process.env.PORT ?? 3000);
app.listen(port, () => {
  logger.info({ port }, "Web Archiver server listening");
});
